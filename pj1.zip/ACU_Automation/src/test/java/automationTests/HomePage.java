package automationTests;

import org.testng.annotations.*;
import java.awt.event.KeyEvent;

import baseClass.TestBase;

public class HomePage extends TestBase{
  
	@Test
	public void homePageSearch() throws Exception {
		click("searchBtn");
		type("searchTextBox", "Bath");
		keyboardAction(KeyEvent.VK_ENTER);
	}	
	
}