//package utility;
//
//import java.util.Properties;
//
//import javax.activation.DataHandler;
//import javax.activation.DataSource;
//import javax.activation.FileDataSource;
//import javax.mail.BodyPart;
//import javax.mail.Message;
//import javax.mail.MessagingException;
//import javax.mail.Multipart;
//import javax.mail.PasswordAuthentication;
//import javax.mail.Session;
//import javax.mail.Transport;
//import javax.mail.internet.InternetAddress;
//import javax.mail.internet.MimeBodyPart;
//import javax.mail.internet.MimeMessage;
//import javax.mail.internet.MimeMultipart;
//
//import baseClass.TestBase;
//
///**************************This class has the main code for sending mail*********************************/
//
//public class SendMail extends TestBase{
//
//	public static void send(String from ,String tos[], String ccs[], String subject,String textMessageBody) throws MessagingException {
//
//		//Decrypted password
//		String decryptedPassword = decryptPassword("sendmail.password_encrypted");
//
//		// Get the session object
//		Properties props = new Properties();
//
//		if(Config.getProperty("sendmail.smtp.host").equalsIgnoreCase("smtp.office365.com")) {
//			
//			props.put("mail.smtp.host", Config.getProperty("sendmail.smtp.host"));
//			props.put("mail.smtp.port", Config.getProperty("sendmail.smtp.port")); // TLS Port
//			props.put("-Dmail.smtp.starttls.enable", "true");
//			props.put("mail.smtp.starttls.enable", "true");
//			props.put("mail.smtp.auth", "true");
//			props.put("mail.store.protocol", "SMTP");
//
//		}else if(Config.getProperty("sendmail.smtp.host").equalsIgnoreCase("smtp.gmail.com")) {
//			
//			props.put("mail.smtp.host", Config.getProperty("sendmail.smtp.host"));
//			props.put("mail.smtp.socketFactory.port", Config.getProperty("sendmail.smtp.port"));
//			props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
//			props.put("mail.smtp.auth", "true"); 
//			props.put("mail.smtp.port", Config.getProperty("sendmail.smtp.port"));
//			
//		}else{
//			
//			System.out.println();
//		}
//
//		Session session = Session.getDefaultInstance(props,
//				new javax.mail.Authenticator() {
//			protected PasswordAuthentication getPasswordAuthentication() {
//				return new PasswordAuthentication(from,decryptedPassword);
//			}
//		});
//
//		// compose message
//		try {
//			MimeMessage message = new MimeMessage(session);
//			message.setFrom(new InternetAddress(from));
//			for (String to : tos) {
//				
//				message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
//				
//			}
//			
//			for (String cc : ccs) {
//				
//				message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(cc));
//				
//			}
//			 
//			message.setSubject(subject);
//			// Option 1: To send normal text message
//			// message.setText(text);
//			// Option 2: Send the actual HTML message, as big as you like
//			// message.setContent("<h1>This is actual message</h1></br></hr>" +
//			// text, "text/html");
//
//			// Set the attachment path
//			String filePath = ExtentManager.ExtentReportFullPath;
//			
//			BodyPart objMessageBodyPart = new MimeBodyPart();
//			// Option 3: Send text along with attachment
//			objMessageBodyPart.setContent(
//					
//					"<div style=\"background-color:yellow;width:600px;padding:1px;\"><b>THIS IS AN AUTOMATED EMAIL FOR AUTOMATION TEST EXECUTION !!!</b></div></br>"
//					+"<p>Hi Team,</br></br></p>"
//					+"<p>Automation script is executed.</p>"
//					+ textMessageBody+
//					"<p>Regards,</br>"
//					+Config.getProperty("sendmail.from.name")+"</p>", 
//					"text/html");
//			
//			Multipart multipart = new MimeMultipart();
//			multipart.addBodyPart(objMessageBodyPart);
//
//			objMessageBodyPart = new MimeBodyPart();
//			DataSource source = new FileDataSource(filePath);
//			objMessageBodyPart.setDataHandler(new DataHandler(source));
//			objMessageBodyPart.setFileName(ExtentManager.ExtentReportName);
//			multipart.addBodyPart(objMessageBodyPart);
//			
//			message.setContent(multipart);
//
//			// send message
//			Transport.send(message);
//			
//			log.debug("Email sent successfully");
//
//			System.out.println("Email sent successfully");
//
//		} catch (MessagingException e) {
//
//			throw new RuntimeException(e);
//		}
//	}// End of SEND method
//}
