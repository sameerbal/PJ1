package utility;

import java.io.File;

import com.relevantcodes.extentreports.DisplayOrder;
import com.relevantcodes.extentreports.ExtentReports;

public class ExtentManager {
	
	private static ExtentReports extent;
	
	public static String ExtentReportName = "ExtentReport.html";
	
	public static String ExtentReportInitialPath = System.getProperty(("user.dir"))+"\\src\\main\\resources\\ExtentReport_Folder\\";
	
	public static String ExtentReportFullPath = ExtentReportInitialPath+ExtentReportName;
	
	public static ExtentReports getInstance() {
		
		if(extent == null) {
			
			extent = new ExtentReports(ExtentReportFullPath,true,DisplayOrder.OLDEST_FIRST);
			
			extent.loadConfig(new File(System.getProperty(("user.dir"))+"\\src\\test\\resources\\extentConfig\\ReportsConfig.xml"));
		}
		
		return extent;
	}

}
