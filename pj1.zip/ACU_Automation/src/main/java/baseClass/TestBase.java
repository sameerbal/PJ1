package baseClass;

import static org.testng.Assert.assertTrue;

import java.awt.Robot;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Base64;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.*;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import utility.ExtentManager;

public class TestBase {

	public static WebDriver driver;
	public static Properties Config = new Properties();
	public static Properties OR = new Properties();
	public static FileInputStream fis;
	public static Logger log = Logger.getLogger("devpinoyLogger");
	public static ExtentReports rep = ExtentManager.getInstance();
	public static ExtentTest test;

	@BeforeSuite
	public void setUp() throws IOException {

		log.debug("Execution Started...!!!");

		if (driver == null) {

			FileInputStream fis = new FileInputStream(
					System.getProperty("user.dir") + "\\src\\test\\resources\\properties\\Config.properties");

			Config.load(fis);

			log.debug("Configuration file loaded...!!!");

			fis = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\properties\\OR.properties");

			OR.load(fis);

			log.debug("Object repository file loaded...!!!");
		}

		if (Config.getProperty("browser").equalsIgnoreCase("firefox")) {

			System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "\\src\\main\\resources\\Drivers\\geckodriver.exe");

			driver = new FirefoxDriver();

			log.debug("FireFox browser launched !!!");

			log.debug("Launching " +Config.getProperty("browser")+ "browser");

			//test.log(LogStatus.INFO, "'"+Config.getProperty("browser")+"' browser launched");

		} else if (Config.getProperty("browser").equalsIgnoreCase("chrome")) {

			System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\src\\main\\resources\\Drivers\\chromedriver.exe");

			driver = new ChromeDriver();

			log.debug("Chrome browser launched !!!");

			//test.log(LogStatus.INFO, "'"+Config.getProperty("browser")+"' browser launched");

		} else if (Config.getProperty("browser").equalsIgnoreCase("ie")) {

			System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "\\src\\main\\resources\\Drivers\\IEDriverServer.exe");

			driver = new InternetExplorerDriver();

			log.debug("IE browser launched !!!");

			//test.log(LogStatus.INFO, "'"+Config.getProperty("browser")+"' browser launched");

		} else {

			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "\\src\\main\\resources\\Drivers\\chromedriver.exe");

			driver = new ChromeDriver();

			log.debug("No input found for browser, default browser chrome is launched !!!");

			//test.log(LogStatus.INFO, "'"+Config.getProperty("browser")+"' browser launched");
		}

		driver.manage().timeouts().implicitlyWait(Integer.parseInt(Config.getProperty("implicit.wait")),
				TimeUnit.SECONDS);

		driver.manage().window().maximize();
		
		//test.log(LogStatus.INFO, "Working on URL: '"+Config.getProperty("URL")+"'");

		driver.get(Config.getProperty("URL"));

	}

	/**************************
	 * Methods Start
	 * @throws Exception 
	 ***********************************************************************************/

	/************************Generic methods********************************************/

	//Click generic method
	public void click(String locator) throws Exception {

		WebElement element = getLocator(locator);
		
		if(element != null) {

		JavascriptExecutor js = (JavascriptExecutor)driver;

		js.executeScript("arguments[0].click();", element);

		test.log(LogStatus.INFO, "Clicked on: '"+locator+"'");
		
		}

	}

	//SendKeys generic method
	public void type(String locator, String value) throws Exception {

		WebElement element = getLocator(locator);
		
		if(element != null) {

		element.sendKeys(value);

		if(locator.endsWith("_password")) {

			test.log(LogStatus.INFO, "Value 'XXXXX' enetered in textfield: '"+locator+ "'");

		}else {

			test.log(LogStatus.INFO, "Value '"+value+"' enetered in textfield: '"+locator+ "'");

		}
		
		}

	}

	//Verify element is present generic method
	public boolean isElementPresent(String locator) throws Exception {

		try {

			WebElement element = getLocator(locator);

			element.isDisplayed();

			test.log(LogStatus.INFO, "Verification done for element: '"+locator+"'.This element is present on page");
			
			return true;

		} catch (Exception e) {

			return false;

		}

	}

	//Assert generic methods
	public void assertVerification(String locatorLabel) throws Exception {

		Assert.assertTrue(isElementPresent(locatorLabel), "Element not found");

		log.debug("Verification Done for "+locatorLabel);

		//test.log(LogStatus.INFO, "'"+locatorLabel+ "' found on page");
	}

	public void assertFalseVerification(String locatorLabel) throws Exception {

		Assert.assertFalse(isElementPresent(locatorLabel), "Unexpected > Element found");

		log.debug("Verification Done for "+locatorLabel+ ", as expected it is not found");

		//test.log(LogStatus.INFO, "'"+locatorLabel+ "' is not found on page > Expected");
	}

	public void assertStringContainsVerification(String locatorLabel, String stringToCompare) throws Exception {
		
		Thread.sleep(2000);

		WebElement element = getLocator(locatorLabel);
		
		if(element != null) {

		String element_getText = element.getText();

		assertTrue(element_getText.contains(stringToCompare), "Text not matched");

		test.log(LogStatus.INFO, "'"+stringToCompare+ "' text is found");
		
		}
	}

	public void assert_isSelected(String locatorLabel) throws Exception {

		WebElement element = getLocator(locatorLabel);
		
		if(element != null) {

		assertTrue(element.isSelected(),"Checkbox is selected");

		test.log(LogStatus.INFO, "'"+locatorLabel+"' checkbox is checked");
		
		}
	}

	public void assert_isNotSelected(String locatorLabel) throws Exception {

		WebElement element = getLocator(locatorLabel);
		
		if(element != null) {

		assertTrue(!element.isSelected(),"Checkbox is not selected");

		test.log(LogStatus.INFO, "'"+locatorLabel+"' checkbox is not checked");
		
		}
	}

	/*
	 * public void assertEqualStrings(String str1, String str2) throws Exception {
	 * 
	 * assertEqualStrings(str1, str2);
	 * 
	 * test.log(LogStatus.INFO, "Both strings matched"); }
	 */

	// Highlighter generic method for WebElement
		public void highLighterMethod(WebDriver driver, WebElement element) throws Exception {

			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(false);", element);

			JavascriptExecutor js = (JavascriptExecutor) driver;

			js.executeScript("arguments[0].setAttribute('style', 'border: 5px solid yellow;');", element);

		}

	//method to get By
	public By getBy(String OR_locatorLabel) throws Exception  {

		String locator = OR.getProperty(OR_locatorLabel);

		// extract the locator type and value from the object
		String locatorType = locator.split(";")[0];
		String locatorValue = locator.split(";")[1];

		// return an instance of the By class based on the type of the locator
		if(locatorType.toLowerCase().equals("id")) {

			By by = By.id(locatorValue);

			return by;
		}
		else if(locatorType.toLowerCase().equals("name")) {

			By by = By.name(locatorValue);

			return by;
		}
		else if((locatorType.toLowerCase().equals("classname")) || (locatorType.toLowerCase().equals("class"))) {

			By by = By.className(locatorValue);

			return by;
		}
		else if((locatorType.toLowerCase().equals("tagname")) || (locatorType.toLowerCase().equals("tag"))) {

			By by = By.tagName(locatorValue);

			return by;
		}
		else if((locatorType.toLowerCase().equals("linktext")) || (locatorType.toLowerCase().equals("link"))) {

			By by = By.linkText(locatorValue);

			return by;
		}
		else if(locatorType.toLowerCase().equals("partiallinktext")) {

			By by = By.partialLinkText(locatorValue);

			return by;
		}
		else if((locatorType.toLowerCase().equals("cssselector")) || (locatorType.toLowerCase().equals("css"))) {

			By by = By.cssSelector(locatorValue);

			return by;
		}
		else if(locatorType.toLowerCase().equals("xpath")) {

			By by = By.xpath(locatorValue);

			return by;
		}
		else
			throw new Exception("Unknown locator type '" + locatorType + "'");
	}

	//method to return web element
	public WebElement getLocator(String OR_locatorLabel) throws Exception {

		WebElement element = null;
		
		By by = fluentWaiting(OR_locatorLabel);		

		//By by = getBy(OR_locatorLabel);
		
		if(by != null) {
		
		element = driver.findElement(by);

		highLighterMethod(driver, element);
		
		}
		
		return element;	
	}

	//method to return list of web elements
	public List <WebElement> getLocators(String OR_locatorLabel) throws Exception {

		List <WebElement> elements = null;
		
		By by = fluentWaiting(OR_locatorLabel);		
		
		if(by != null) {

		elements = driver.findElements(by);	
		
		}
		
		return elements;
	}

	//Fluent Wait method
	public By fluentWaiting(String OR_locatorLabel) throws Exception {
		
		By by = null;

		try {
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(Integer.parseInt(Config.getProperty("fluentwait.max.time"))))
				.pollingEvery(Duration.ofSeconds(Integer.parseInt(Config.getProperty("fluentwait.polling.time"))))
				.ignoring(Exception.class);

		wait.until(ExpectedConditions.presenceOfElementLocated(getBy(OR_locatorLabel)));

		by = getBy(OR_locatorLabel);

		return by;
		
		}catch(Exception e) {
			
			test.log(LogStatus.FAIL, "Expected element not present");
			return by;
		}
	}

	//Decrypt password generic method
	public static String decryptPassword(String encodedPwd) {

		// Decoding encrypted password
		byte[] decryptedPasswordBytes = Base64.getDecoder().decode(Config.getProperty(encodedPwd));
		String decryptedPassword = new String(decryptedPasswordBytes);

		return decryptedPassword;
	}

	//Keyboard action generic method
	public void keyboardAction(int key) throws Exception {

		Robot robot = new Robot();
		// Simulate key Events
		robot.keyPress(key);
		robot.keyRelease(key);

	}

	//Mouse hover generic method
	public void mouseHover(String locatorLabel) throws Exception {

		WebElement element = getLocator(locatorLabel);

		//highLighterMethod(driver, element);
		
		if(element != null) {

		//Create object 'action' of an Actions class
		Actions action = new Actions(driver);

		//Mouseover on an element
		action.moveToElement(element)/* .build() */.perform();

		test.log(LogStatus.INFO, "Mouse hover on: "+locatorLabel);
		
		}

	}

	public void dropdownSelect(String locatorLabel, String valueToSelect) throws Exception {
		
		try {

		WebElement element = getLocator(locatorLabel);
		
		if(element != null) {

		Select ddl = new Select(element);

		ddl.selectByVisibleText(valueToSelect);

		test.log(LogStatus.INFO, "Selected '"+valueToSelect+ "' from dropdown: '"+locatorLabel+"'");
		
		}
		
		}catch(Exception e) {
			
			test.log(LogStatus.INFO, "Value: '"+valueToSelect+ "' is not available in dropdown");
		}
	}

	public void switchToChildWindowHandle() throws InterruptedException {

		// It will return the parent window name as a String
		String mainWindow = driver.getWindowHandle();

		// It returns no. of windows opened by WebDriver and will return Set of Strings
		Set<String> windowHandles = driver.getWindowHandles();

		// Using Iterator to iterate with in windows
		Iterator<String> itr = windowHandles.iterator();

		while(itr.hasNext()){

			String childWindow=itr.next();

			// Compare whether the main windows is not equal to child window. If not equal, we will close.
			if(!mainWindow.equalsIgnoreCase(childWindow)){

				driver.switchTo().window(childWindow);
				
				Thread.sleep(1000);

				System.out.println(driver.switchTo().window(childWindow).getTitle());
			}
		}
	}

	/**************************
	 * Methods End
	 ***********************************************************************************/

	@AfterSuite
	public void tearDown() {

		if (driver != null) {

			driver.quit();

			log.debug("Execution completed !!!");

		}

	}

}
