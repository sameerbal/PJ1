package listeners;

import java.io.IOException;

import javax.mail.MessagingException;

import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

import com.relevantcodes.extentreports.LogStatus;

import baseClass.TestBase;
import utility.TestUtil;


public class CustomListeners extends TestBase implements ITestListener,ISuiteListener {
	
	public void onTestStart(ITestResult arg0) {

		test = rep.startTest(arg0.getName().toUpperCase());
      
	}

	public void onTestSuccess(ITestResult arg0) {

		test.log(LogStatus.PASS, arg0.getName().toUpperCase()+" PASS");
		
		rep.endTest(test);
		
		rep.flush();
		
	}

	public void onTestFailure(ITestResult arg0) {

		try { 

			TestUtil.captureScreenshot(); 

		} catch (IOException e) {

			e.printStackTrace(); 

		}
		
		test.log(LogStatus.FAIL, arg0.getName().toUpperCase()+" Failed with exception: "+ arg0.getThrowable());
		
		test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotPath));

		System.setProperty("org.uncommons.reportng.escape-output", "false");

		Reporter.log("Click to see Screenshot");

		//Reporter.log("<a target=\"_blank\" href="+TestUtil.screenshotPath+"></a>");

		//Reporter.log("<br>");

		//Reporter.log("<a target=\"_blank\" href="+TestUtil.screenshotPath+"><img src="+TestUtil.screenshotPath+" height=500 width=500></img></a>");

		rep.endTest(test);
		
		rep.flush();
	}
	
	public void onFinish(ISuite arg0) {
		
		String[] tos = {Config.getProperty("sendmail.to")};
		
		String[] ccs = {Config.getProperty("sendmail.cc")};
		
		String subject = "Automation report executed on '"+Config.getProperty("browser")+"' browser.";

//		try {
//			
//			SendMail.send(Config.getProperty("sendmail.from"), tos, ccs, subject , "Please see attached Execution Report with details");
//		
//		} catch (MessagingException e) {
//			
//			e.printStackTrace();
//		}	
		
	}


}

